# Library-Management-System
This is an application which maintains all the details of books in library also shows the detail of the books 
and when the book was issued and by what date the book should be returned
